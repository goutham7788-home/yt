document.addEventListener("DOMContentLoaded", () => {
  const sliderContainer = document.querySelector(".slider-container");
  const images = sliderContainer.querySelectorAll("img");

  let currentIndex = 0;

  function moveToNextImage() {
    // Move the slider to the next image
    currentIndex++;
    if (currentIndex >= images.length) {
      currentIndex = 0; // If we reach the last image, start over
    }
    sliderContainer.style.transform = `translateX(-${currentIndex * 100}%)`;
  }

  // Change the image every 3 seconds (3000ms)
  setInterval(moveToNextImage, 2000);
});
document.addEventListener("DOMContentLoaded", () => {
  const quoteContainer = document.querySelector(".quote-container");
  const quotes = quoteContainer.querySelectorAll(".quote-item");

  let currentIndex = 0;

  function moveToNextQuote() {
    // Move the slider to the next quote
    currentIndex++;
    if (currentIndex >= quotes.length) {
      currentIndex = 0; // If we reach the last quote, start over
    }
    quoteContainer.style.transform = `translateX(-${currentIndex * 100}%)`;
  }

  // Change the quote every 4 seconds (4000ms)
  setInterval(moveToNextQuote, 5000);
});
